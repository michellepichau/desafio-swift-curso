import Foundation

class Book {
    var title: String
    var author: String
    var publicationYear: Int
    var genre: Genre
    var available: Bool = true

    init(title: String, author: String, publicationYear: Int, genre: Genre) {
        self.title = title
        self.author = author
        self.publicationYear = publicationYear
        self.genre = genre
    }

    func details() -> String {
        return "Title: \(title), Author: \(author), Year: \(publicationYear), Genre: \(genre)"
    }
}

class User {
    var name: String
    var age: Int
    var borrowedBooks: [Book] = []

    init(name: String, age: Int) {
        self.name = name
        self.age = age
    }

    func borrowBook(_ book: Book) {
        if book.available {
            borrowedBooks.append(book)
            book.available = false
            print("\(name) borrowed the book '\(book.title)'.")
        } else {
            print("The book '\(book.title)' is not available.")
        }
    }

    func returnBook(_ book: Book) {
        if let index = borrowedBooks.firstIndex(where: { $0.title == book.title }) {
            borrowedBooks.remove(at: index)
            book.available = true
            print("\(name) returned the book '\(book.title)'.")
        } else {
            print("\(name) does not have the book '\(book.title)'.")
        }
    }
}

class Library {
    var books: [Book] = []

    func addBook(_ book: Book) {
        books.append(book)
    }

    func listAvailableBooks() {
        let availableBooks = books.filter { $0.available }
        for book in availableBooks {
            print(book.details())
        }
    }
}


enum Genre {
    case fiction, nonFiction, fantasy, romance, mystery
}


let book1 = Book(title: "The Hobbit", author: "J.R.R. Tolkien", publicationYear: 1937, genre: .fantasy)
let book2 = Book(title: "1984", author: "George Orwell", publicationYear: 1949, genre: .fiction)

let user = User(name: "John", age: 25)

let library = Library()
library.addBook(book1)
library.addBook(book2)

print("Available books:")
library.listAvailableBooks()

user.borrowBook(book1)

print("\nAvailable books after borrowing:")
library.listAvailableBooks()
