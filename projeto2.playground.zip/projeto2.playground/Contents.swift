import Foundation

protocol Notifiable {
    func receiveNotification(_ notification: Notification)
}

protocol Notification {
    var title: String { get }
    var message: String { get }
    var date: Date { get }
}


struct User: Notifiable {
    var name: String
    var notifications: [Notification] = []

    mutating func receiveNotification(_ notification: Notification) {
        notifications.append(notification)
        print("\(name) received a notification: \(notification.title)")
    }
}

struct Article: Notification {
    var title: String
    var message: String
    var date: Date
}

var user = User(name: "Maria")

let article1 = Article(title: "New Discovery", message: "A new planet has been discovered!", date: Date())
let article2 = Article(title: "Tech Advances", message: "New technology is revolutionizing the industry.", date: Date())

user.receiveNotification(article1)
user.receiveNotification(article2)

print("\nReceived notifications:")
for notification in user.notifications {
    print("\(notification.title) - \(notification.message) on \(notification.date)")
}
